import { ValidarRepetirDirective } from './validar-repetir.directive';

describe('ValidarRepetirDirective', () => {
  it('should create an instance', () => {
    const directive = new ValidarRepetirDirective();
    expect(directive).toBeTruthy();
  });
});
