import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appSoloLetras]',
})
export class SoloLetrasDirective {
  constructor() {}

}
