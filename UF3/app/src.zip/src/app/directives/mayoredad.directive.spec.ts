import { MayoredadDirective } from './mayoredad.directive';

describe('MayoredadDirective', () => {
  it('should create an instance', () => {
    const directive = new MayoredadDirective();
    expect(directive).toBeTruthy();
  });
});
