'use strict'
//importacions i creació de constants per a la seva utiliutzació
const express = require('express')
const bodyParser = require('body-parser')
const mysql = require('mysql')
const cors = require('cors')

const app = express()
app.use(cors())// todos los accesos estan "protegidos" de error de CORS
//configuració del bodyParser perquè admeti entrades json i
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

var connection = mysql.createConnection({
    host: 'localhost',// servidor de BBDD
    database: 'm06',
    user: 'userangular',// usuario con los minimos privilegios posibles
    password: 'alumne123'
});


app.get('/', (req, res) => {
    res.send({ message: 'Hola món' })
})

// consultas a mi BBDD
// servimos por GET el recurso /api/login
app.get('/api/login', function (req, res) {
    console.log("estem a login");
    connection.connect(function (err) {
        console.log(err);
        if (err) {
            console.error('Error connecting: ' + err.stack);
            return;
        }
        console.log('Connected as id ' + connection.threadId);// Llego si no hay error
    });
    connection.query('SELECT * FROM users', function (error, results, field) {
        if (error) {
            res.status(400).send({ resultats: null })
        } else {
            res.status(200).send({ resultats: results })
        }
    });
})

app.listen(3000, () => {
    console.log('Aquesta és la nostra API-REST que corre en http://localhost:3000')
})