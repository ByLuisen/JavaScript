import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { isEmpty } from 'rxjs';
import { Producte } from 'src/app/model/Producte';
import { MerchandisingComponent } from '../merchandising/merchandising.component';

@Component({
  selector: 'app-compra',
  templateUrl: './compra.component.html',
  styleUrls: ['./compra.component.css'],
})
export class CompraComponent implements OnInit {
  //Input para recibir el producto de merchandising
  @Input() producto!: Producte;
//creamos el Producto
  carrito: Producte[] = [];
//array push a carrito con los datos de producto
  ngOnInit(): void {
      this.carrito.push(this.producto)
  }
}
