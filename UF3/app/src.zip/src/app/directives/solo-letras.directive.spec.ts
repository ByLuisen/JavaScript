import { SoloLetrasDirective } from './solo-letras.directive';

describe('SoloLetrasDirective', () => {
  it('should create an instance', () => {
    const directive = new SoloLetrasDirective();
    expect(directive).toBeTruthy();
  });
});
