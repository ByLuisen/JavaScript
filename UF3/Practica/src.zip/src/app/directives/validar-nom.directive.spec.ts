import { ValidarNomDirective } from './validar-nom.directive';

describe('ValidarNomDirective', () => {
  it('should create an instance', () => {
    const directive = new ValidarNomDirective();
    expect(directive).toBeTruthy();
  });
});
